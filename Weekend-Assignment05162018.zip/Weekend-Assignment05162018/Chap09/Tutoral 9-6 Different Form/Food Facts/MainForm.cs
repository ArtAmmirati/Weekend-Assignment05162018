﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Food_Facts
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void exitbutton2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void displaybutton1_Click(object sender, EventArgs e)
        {
            NutritionForm nutriForm = new NutritionForm();

            if (BanannaradioButton1.Checked)
            {
                nutriForm.label6.Text = "1 Bananna";
                nutriForm.label7.Text = "100";
                nutriForm.label8.Text = "0.4";
                nutriForm.label9.Text = "27";
            }
            else if (popcornradioButton2.Checked)
            {
                nutriForm.label6.Text = "1 Cup of Air-Popped Popcorn";
                nutriForm.label7.Text = "31";
                nutriForm.label8.Text = "0.4";
                nutriForm.label9.Text = "6";
            }
            else if (muffinradioButton3.Checked)
            {
                nutriForm.label6.Text = "1 Large Muffin";
                nutriForm.label7.Text = "385";
                nutriForm.label8.Text = "9";
                nutriForm.label9.Text = "67";
            }
            nutriForm.ShowDialog();
        }
    }
}
