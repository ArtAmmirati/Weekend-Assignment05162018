﻿namespace Food_Facts
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.BanannaradioButton1 = new System.Windows.Forms.RadioButton();
            this.popcornradioButton2 = new System.Windows.Forms.RadioButton();
            this.muffinradioButton3 = new System.Windows.Forms.RadioButton();
            this.displaybutton1 = new System.Windows.Forms.Button();
            this.exitbutton2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select a Food";
            // 
            // BanannaradioButton1
            // 
            this.BanannaradioButton1.AutoSize = true;
            this.BanannaradioButton1.Location = new System.Drawing.Point(16, 33);
            this.BanannaradioButton1.Name = "BanannaradioButton1";
            this.BanannaradioButton1.Size = new System.Drawing.Size(86, 17);
            this.BanannaradioButton1.TabIndex = 1;
            this.BanannaradioButton1.TabStop = true;
            this.BanannaradioButton1.Text = "1 BANANNA";
            this.BanannaradioButton1.UseVisualStyleBackColor = true;
            // 
            // popcornradioButton2
            // 
            this.popcornradioButton2.AutoSize = true;
            this.popcornradioButton2.Location = new System.Drawing.Point(16, 61);
            this.popcornradioButton2.Name = "popcornradioButton2";
            this.popcornradioButton2.Size = new System.Drawing.Size(197, 17);
            this.popcornradioButton2.TabIndex = 2;
            this.popcornradioButton2.TabStop = true;
            this.popcornradioButton2.Text = "1 CUP OF AIR-POPPED POPCORN";
            this.popcornradioButton2.UseVisualStyleBackColor = true;
            // 
            // muffinradioButton3
            // 
            this.muffinradioButton3.AutoSize = true;
            this.muffinradioButton3.Location = new System.Drawing.Point(16, 89);
            this.muffinradioButton3.Name = "muffinradioButton3";
            this.muffinradioButton3.Size = new System.Drawing.Size(113, 17);
            this.muffinradioButton3.TabIndex = 3;
            this.muffinradioButton3.TabStop = true;
            this.muffinradioButton3.Text = "1 LARGE MUFFIN";
            this.muffinradioButton3.UseVisualStyleBackColor = true;
            // 
            // displaybutton1
            // 
            this.displaybutton1.Location = new System.Drawing.Point(16, 137);
            this.displaybutton1.Name = "displaybutton1";
            this.displaybutton1.Size = new System.Drawing.Size(94, 71);
            this.displaybutton1.TabIndex = 4;
            this.displaybutton1.Text = "Display Food Facts";
            this.displaybutton1.UseVisualStyleBackColor = true;
            this.displaybutton1.Click += new System.EventHandler(this.displaybutton1_Click);
            // 
            // exitbutton2
            // 
            this.exitbutton2.Location = new System.Drawing.Point(168, 137);
            this.exitbutton2.Name = "exitbutton2";
            this.exitbutton2.Size = new System.Drawing.Size(94, 71);
            this.exitbutton2.TabIndex = 5;
            this.exitbutton2.Text = "Exit";
            this.exitbutton2.UseVisualStyleBackColor = true;
            this.exitbutton2.Click += new System.EventHandler(this.exitbutton2_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(281, 232);
            this.Controls.Add(this.exitbutton2);
            this.Controls.Add(this.displaybutton1);
            this.Controls.Add(this.muffinradioButton3);
            this.Controls.Add(this.popcornradioButton2);
            this.Controls.Add(this.BanannaradioButton1);
            this.Controls.Add(this.label1);
            this.Name = "MainForm";
            this.Text = "Food Facts";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton BanannaradioButton1;
        private System.Windows.Forms.RadioButton popcornradioButton2;
        private System.Windows.Forms.RadioButton muffinradioButton3;
        private System.Windows.Forms.Button displaybutton1;
        private System.Windows.Forms.Button exitbutton2;
    }
}

